// Local source-pixel/sampling attribution only. Original asset bytes, texture
// loader and renderer are unchanged. This readback probe is NOT a memory run.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, existsSync, openSync, closeSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { resolve, extname } from 'node:path';
const directory = new URL('.', import.meta.url).pathname, root = resolve(directory, '..');
const require = createRequire(resolve(root, 'frontend/package.json'));
const engine = process.env.CRYPTOID_TEST_ENGINE || 'chromium', tag = process.env.CRYPTOID_NATIVE_OUTPUT_TAG;
assert.ok(['chromium', 'webkit'].includes(engine)); assert.ok(tag && /^[a-z0-9-]{1,40}$/.test(tag));
const artifacts = resolve(root, 'verification/rebuild'); mkdirSync(artifacts, { recursive: true });
const out = resolve(artifacts, `source-pixels-${engine}-${tag}.json`); closeSync(openSync(out, 'wx'));
const result = { engine, tag, sourceCommit: '4681d224d3aa3d87e96611485666dc8c8bbaaafc', memoryAcceptance: false,
  historicalWhiteScreenFixed: false, forcedGC: false, pixelReadback: true, originalAssets: [], comparisons: [], errors: [], complete: false };
let browser, server;
try {
  const { build } = require('esbuild');
  const bundle = await build({ stdin: { contents: "export {loadTexture} from './browser/textures.ts'", resolveDir: directory, loader: 'ts' },
    bundle: true, write: false, format: 'iife', platform: 'browser', globalName: 'textureProbe', logLevel: 'silent' });
  const js = bundle.outputFiles[0].text;
  const manifest = JSON.parse(readFileSync(resolve(directory, 'fixture/memoryAssetManifest.json'), 'utf8'));
  const specs = [
    { url: manifest.assets.find(a => a.provenance === 'local-generated-released-catalog').url, maxWidth: 282, maxHeight: 282, maxEncodedBytes: 512000 },
    { url: '/ships/bosses/evolved/boss-04-hull.webp', maxWidth: 1000, maxHeight: 375, maxEncodedBytes: 79186 },
    { url: '/ships/bosses/evolved/boss-04-guns.webp', maxWidth: 2048, maxHeight: 966, maxEncodedBytes: 46594 },
  ];
  for (const spec of specs) {
    const data = readFileSync(resolve(root, 'frontend/public' + spec.url));
    const sha = createHash('sha1').update(Buffer.from(`blob ${data.length}\0`)).update(data).digest('hex');
    assert.equal(sha, manifest.assets.find(a => a.url === spec.url).sha); result.originalAssets.push({ url: spec.url, sha, bytes: data.length });
  }
  server = createServer((req, res) => {
    const path = new URL(req.url, 'http://localhost').pathname;
    if (path === '/probe.js') { res.setHeader('Content-Type', 'application/javascript'); res.end(js); return; }
    if (specs.some(spec => spec.url === path)) { res.setHeader('Content-Type', extname(path) === '.webp' ? 'image/webp' : 'image/png'); res.end(readFileSync(resolve(root, 'frontend/public' + path))); return; }
    if (path === '/') {
      res.setHeader('Content-Type', 'text/html');
      res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self'; img-src 'self' blob:; connect-src 'self'");
      res.end('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><script src="/probe.js"></script></body></html>'); return;
    }
    res.writeHead(path === '/favicon.ico' ? 204 : 404); res.end();
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const playwright = engine === 'webkit' ? require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright')
    : require(resolve(root, 'verification/browser-tools/node_modules/playwright'));
  const options = { headless: true, timeout: 20000 };
  if (engine === 'webkit') {
    const base = '/root/.cache/ms-playwright/webkit-2336/minibrowser-wpe', libs = resolve(root, 'verification/webkit-libs/usr/lib/x86_64-linux-gnu');
    options.executablePath = base + '/bin/MiniBrowser';
    options.env = { ...process.env, WEBKIT_EXEC_PATH: base + '/bin', WEBKIT_INJECTED_BUNDLE_PATH: base + '/lib', WEBKIT_INSPECTOR_RESOURCES_PATH: base + '/share',
      LD_LIBRARY_PATH: `${base}/lib:${base}/sys/lib:${libs}`, GST_PLUGIN_SYSTEM_PATH_1_0: libs + '/gstreamer-1.0',
      GST_PLUGIN_SCANNER: libs + '/gstreamer1.0/gstreamer-1.0/gst-plugin-scanner', GST_REGISTRY_1_0: resolve(root, 'verification/webkit-native-audio-registry.bin') };
  }
  browser = await playwright[engine].launch(options); result.version = browser.version();
  const context = await browser.newContext({ viewport: { width: 393, height: 744 }, deviceScaleFactor: 3 });
  const page = await context.newPage(); page.on('pageerror', error => result.errors.push(String(error))); page.setDefaultTimeout(20000);
  await page.goto(`http://127.0.0.1:${server.address().port}`, { waitUntil: 'load' });
  result.comparisons = await page.evaluate(async specs => {
    const compare = (a, b) => {
      let channels = 0, maxDelta = 0, absoluteError = 0;
      for (let i = 0; i < a.length; i++) { const d = Math.abs(a[i] - b[i]); if (d) channels++; maxDelta = Math.max(maxDelta, d); absoluteError += d; }
      return { channels, maxDelta, absoluteError, comparedChannels: a.length };
    };
    const rows = [];
    for (const spec of specs) for (const scale of [.5, .25, 1]) {
      const frames = [];
      for (const decoder of ['image', 'image', 'blob-image', 'bitmap']) {
        const controller = new AbortController();
        const texture = await textureProbe.loadTexture(spec, controller.signal, decoder);
        const canvas = document.createElement('canvas');
        try {
          canvas.width = Math.ceil(texture.value.width * scale); canvas.height = Math.ceil(texture.value.height * scale);
          const context = canvas.getContext('2d'); if (!context) throw new Error('Source pixel context unavailable');
          context.imageSmoothingQuality = 'low'; context.drawImage(texture.value.source, 0, 0, canvas.width, canvas.height);
          frames.push(context.getImageData(0, 0, canvas.width, canvas.height).data);
        } finally { texture.dispose(); controller.abort(); canvas.width = canvas.height = 0; }
      }
      rows.push({ url: spec.url, scale, independentImageControl: compare(frames[1], frames[0]),
        blobVsImage: compare(frames[2], frames[0]), bitmapVsImage: compare(frames[3], frames[0]) });
    }
    return rows;
  }, specs);
  for (const row of result.comparisons) assert.equal(row.independentImageControl.channels, 0, 'Independent reference must be deterministic');
  assert.deepEqual(result.errors, []); result.complete = true;
} catch (error) { result.failure = String(error?.stack || error); process.exitCode = 1; }
finally {
  writeFileSync(out, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ engine, complete: result.complete, comparisons: result.comparisons, failure: result.failure ?? null, out }));
  await browser?.close();
  if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
}
